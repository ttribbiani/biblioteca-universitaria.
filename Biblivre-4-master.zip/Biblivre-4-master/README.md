# Biblivre-4
Biblioteca Livre Internacional 4.0

A forma mais fácil de executar o sistema é através do Eclipse usando o Tomcat 7 como servidor de aplicação.

Carregue o arquivo sql\biblivre3.sql em sua base de dados.

Versão do código atual: 4.0.0
